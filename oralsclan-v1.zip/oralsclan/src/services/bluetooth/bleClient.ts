/**
 * Contrato da futura integração BLE.
 * Nenhuma conexão é simulada aqui. Até o firmware e o UUID do serviço GATT
 * da escova serem definidos, este adaptador retorna indisponibilidade explícita.
 */
export type BrushConnection = {
  connected: boolean;
  deviceId?: string;
  deviceName?: string;
  batteryPercent?: number;
  lastSyncAt?: string;
};

export const initialBrushConnection: BrushConnection = { connected: false };

export async function scanAndConnect(): Promise<BrushConnection> {
  return initialBrushConnection;
}

export async function disconnectBrush(): Promise<void> {
  // O cliente BLE real será implementado após a definição do protocolo GATT.
}

export const BLE_INTEGRATION_STATUS =
  'A integração BLE está preparada por interface, mas aguarda o hardware, o firmware e os UUIDs GATT oficiais.';
