import * as SQLite from 'expo-sqlite';
import type { BrushingSession, CartEntry, Order, ReminderSettings, UserProfile } from '@/types';

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

export async function getDatabase() {
  if (!databasePromise) {
    databasePromise = SQLite.openDatabaseAsync('oralsclan.db');
  }
  const db = await databasePromise;
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS brushing_sessions (
      id TEXT PRIMARY KEY NOT NULL,
      owner_id TEXT NOT NULL DEFAULT 'local',
      occurred_at TEXT NOT NULL,
      duration_seconds INTEGER NOT NULL,
      source TEXT NOT NULL DEFAULT 'manual',
      note TEXT
    );
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY NOT NULL,
      owner_id TEXT NOT NULL DEFAULT 'local',
      created_at TEXT NOT NULL,
      items_json TEXT NOT NULL,
      total REAL NOT NULL,
      status TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS app_config (
      config_key TEXT PRIMARY KEY NOT NULL,
      config_value TEXT NOT NULL
    );
  `);
  // Migration leve para instalações que tenham criado o banco antes da separação por usuário.
  const sessionColumns = await db.getAllAsync<{ name: string }>('PRAGMA table_info(brushing_sessions)');
  if (!sessionColumns.some((column) => column.name === 'owner_id')) {
    await db.execAsync("ALTER TABLE brushing_sessions ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'local'");
  }
  const orderColumns = await db.getAllAsync<{ name: string }>('PRAGMA table_info(orders)');
  if (!orderColumns.some((column) => column.name === 'owner_id')) {
    await db.execAsync("ALTER TABLE orders ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'local'");
  }
  await db.execAsync('CREATE INDEX IF NOT EXISTS idx_sessions_owner_date ON brushing_sessions(owner_id, occurred_at)');
  await db.execAsync('CREATE INDEX IF NOT EXISTS idx_orders_owner_date ON orders(owner_id, created_at)');
  return db;
}

export async function listSessions(ownerId = 'local'): Promise<BrushingSession[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<{
    id: string; occurred_at: string; duration_seconds: number; source: 'manual' | 'device'; note: string | null;
  }>('SELECT * FROM brushing_sessions WHERE owner_id = ? ORDER BY occurred_at DESC', ownerId);
  return rows.map((row) => ({
    id: row.id,
    occurredAt: row.occurred_at,
    durationSeconds: row.duration_seconds,
    source: row.source,
    note: row.note ?? undefined,
  }));
}

export async function insertSession(session: BrushingSession, ownerId = 'local') {
  const db = await getDatabase();
  await db.runAsync(
    'INSERT INTO brushing_sessions (id, owner_id, occurred_at, duration_seconds, source, note) VALUES (?, ?, ?, ?, ?, ?)',
    session.id, ownerId, session.occurredAt, session.durationSeconds, session.source, session.note ?? null,
  );
}

export async function listOrders(ownerId = 'local'): Promise<Order[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<{
    id: string; created_at: string; items_json: string; total: number; status: Order['status'];
  }>('SELECT * FROM orders WHERE owner_id = ? ORDER BY created_at DESC', ownerId);
  return rows.map((row) => ({
    id: row.id,
    createdAt: row.created_at,
    items: JSON.parse(row.items_json) as Order['items'],
    total: row.total,
    status: row.status,
  }));
}

export async function insertOrder(order: Order, ownerId = 'local') {
  const db = await getDatabase();
  await db.runAsync(
    'INSERT INTO orders (id, owner_id, created_at, items_json, total, status) VALUES (?, ?, ?, ?, ?, ?)',
    order.id, ownerId, order.createdAt, JSON.stringify(order.items), order.total, order.status,
  );
}

export async function readConfig<T>(key: string, fallback: T): Promise<T> {
  const db = await getDatabase();
  const row = await db.getFirstAsync<{ config_value: string }>(
    'SELECT config_value FROM app_config WHERE config_key = ?', key,
  );
  if (!row) return fallback;
  try { return JSON.parse(row.config_value) as T; } catch { return fallback; }
}

export async function writeConfig<T>(key: string, value: T) {
  const db = await getDatabase();
  await db.runAsync(
    'INSERT INTO app_config (config_key, config_value) VALUES (?, ?) ON CONFLICT(config_key) DO UPDATE SET config_value = excluded.config_value',
    key, JSON.stringify(value),
  );
}

export const defaultProfile: UserProfile = {
  name: 'Visitante',
  email: '',
  createdAt: new Date().toISOString(),
};

export const defaultReminders: ReminderSettings = {
  morningEnabled: false,
  morningTime: '07:30',
  eveningEnabled: false,
  eveningTime: '21:00',
};

export const defaultCart: CartEntry[] = [];
