import * as SecureStore from 'expo-secure-store';
import type { UserProfile } from '@/types';
import { defaultProfile } from './database';

const profileKey = (ownerId: string) => `oralsclan.profile.v1.${ownerId}`;

export async function loadSecureProfile(ownerId = 'local'): Promise<UserProfile> {
  const key = profileKey(ownerId);
  const raw = await SecureStore.getItemAsync(key);
  if (!raw) {
    await saveSecureProfile(defaultProfile, ownerId);
    return defaultProfile;
  }
  try {
    const parsed = JSON.parse(raw) as UserProfile;
    if (!parsed || typeof parsed.name !== 'string' || typeof parsed.email !== 'string' || typeof parsed.createdAt !== 'string') {
      throw new Error('Perfil local inválido.');
    }
    return parsed;
  } catch {
    await saveSecureProfile(defaultProfile, ownerId);
    return defaultProfile;
  }
}

export async function saveSecureProfile(profile: UserProfile, ownerId = 'local') {
  await SecureStore.setItemAsync(profileKey(ownerId), JSON.stringify(profile));
}
