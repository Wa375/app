import * as Notifications from 'expo-notifications';
import type { ReminderSettings } from '@/types';

export async function applyReminderSettings(settings: ReminderSettings) {
  if (!settings.morningEnabled && !settings.eveningEnabled) {
    await Notifications.cancelAllScheduledNotificationsAsync();
    return;
  }
  const permission = await Notifications.getPermissionsAsync();
  const granted = permission.granted || (await Notifications.requestPermissionsAsync()).granted;
  if (!granted) throw new Error('Permissão de notificações não concedida.');
  await Notifications.cancelAllScheduledNotificationsAsync();

  const schedule = async (title: string, body: string, time: string) => {
    const [hour, minute] = time.split(':').map(Number);
    if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      throw new Error(`Horário inválido: ${time}`);
    }
    await Notifications.scheduleNotificationAsync({
      content: { title, body },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour, minute },
    });
  };

  if (settings.morningEnabled) {
    await schedule('Bom dia! Hora de cuidar do sorriso.', 'Reserve alguns minutos para sua higiene bucal.', settings.morningTime);
  }
  if (settings.eveningEnabled) {
    await schedule('Seu cuidado da noite.', 'Não se esqueça da escovação antes de dormir.', settings.eveningTime);
  }
}
