export type SessionSource = 'manual' | 'device';
export type RegionStatus = 'good' | 'attention' | 'priority';

export type BrushingSession = {
  id: string;
  occurredAt: string;
  durationSeconds: number;
  source: SessionSource;
  note?: string;
};

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  icon: string;
  accent: string;
};

export type CartEntry = { productId: string; quantity: number };
export type OrderLine = { productId: string; name: string; unitPrice: number; quantity: number };
export type Order = {
  id: string;
  createdAt: string;
  items: OrderLine[];
  total: number;
  status: 'Aguardando integração de pagamento' | 'Pedido local';
};

export type UserProfile = {
  name: string;
  email: string;
  createdAt: string;
};

export type ReminderSettings = {
  morningEnabled: boolean;
  morningTime: string;
  eveningEnabled: boolean;
  eveningTime: string;
};

export type AppContextValue = {
  ready: boolean;
  profile: UserProfile;
  sessions: BrushingSession[];
  cart: CartEntry[];
  orders: Order[];
  reminders: ReminderSettings;
  backendEnabled: boolean;
  cloudUserId: string | null;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
  recordSession: (durationSeconds: number) => Promise<void>;
  addToCart: (productId: string) => Promise<void>;
  updateCartQuantity: (productId: string, quantity: number) => Promise<void>;
  checkout: () => Promise<Order>;
  updateReminders: (data: ReminderSettings) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
};
