import React from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/theme/colors';

export function Screen({ children, scroll = true, style }: React.PropsWithChildren<{ scroll?: boolean; style?: ViewStyle }>) {
  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      {scroll ? <ScrollView contentContainerStyle={[styles.screen, style]} showsVerticalScrollIndicator={false}>{children}</ScrollView>
        : <View style={[styles.screen, { flex: 1 }, style]}>{children}</View>}
    </SafeAreaView>
  );
}

export function Card({ children, style }: React.PropsWithChildren<{ style?: ViewStyle }>) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Header({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return <View style={styles.headerRow}>
    <View style={{ flex: 1 }}>
      <Text style={styles.pageTitle}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
    {right}
  </View>;
}

export function SectionTitle({ title, action }: { title: string; action?: React.ReactNode }) {
  return <View style={styles.sectionRow}><Text style={styles.sectionTitle}>{title}</Text>{action}</View>;
}

export function Button({ title, onPress, variant = 'primary', icon, disabled, loading }: {
  title: string; onPress: () => void; variant?: 'primary' | 'secondary' | 'outline' | 'danger'; icon?: keyof typeof Ionicons.glyphMap; disabled?: boolean; loading?: boolean;
}) {
  const background = variant === 'primary' ? colors.primary : variant === 'danger' ? colors.danger : variant === 'secondary' ? colors.primarySoft : 'transparent';
  const foreground = variant === 'outline' ? colors.primary : variant === 'secondary' ? colors.primaryDark : '#FFFFFF';
  return <Pressable onPress={onPress} disabled={disabled || loading} style={({ pressed }) => [styles.button, { backgroundColor: background, borderWidth: variant === 'outline' ? 1 : 0, borderColor: colors.border, opacity: disabled ? 0.48 : pressed ? 0.86 : 1 }]}>
    {loading ? <ActivityIndicator color={foreground} /> : <>
      {icon ? <Ionicons name={icon} size={18} color={foreground} /> : null}
      <Text style={[styles.buttonText, { color: foreground }]}>{title}</Text>
    </>}
  </Pressable>;
}

export function Badge({ label, tone = 'blue' }: { label: string; tone?: 'blue' | 'green' | 'yellow' | 'red' | 'grey' }) {
  const palette = {
    blue: [colors.primarySoft, colors.primaryDark], green: [colors.successSoft, colors.success],
    yellow: [colors.warningSoft, colors.warning], red: [colors.dangerSoft, colors.danger], grey: ['#EEF3F6', colors.secondary],
  }[tone];
  return <View style={[styles.badge, { backgroundColor: palette[0] }]}><Text style={[styles.badgeText, { color: palette[1] }]}>{label}</Text></View>;
}

export function StatCard({ label, value, detail, icon, accent = colors.primary }: { label: string; value: string; detail?: string; icon: keyof typeof Ionicons.glyphMap; accent?: string }) {
  return <Card style={styles.statCard}>
    <View style={[styles.statIcon, { backgroundColor: `${accent}18` }]}><Ionicons name={icon} size={19} color={accent} /></View>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    {detail ? <Text style={styles.statDetail}>{detail}</Text> : null}
  </Card>;
}

export function ProgressBar({ value, color = colors.primary }: { value: number; color?: string }) {
  const clamped = Math.max(0, Math.min(100, value));
  return <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${clamped}%`, backgroundColor: color }]} /></View>;
}

export function EmptyState({ icon = 'document-text-outline', title, message }: { icon?: keyof typeof Ionicons.glyphMap; title: string; message: string }) {
  return <View style={styles.emptyState}><View style={styles.emptyIcon}><Ionicons name={icon} size={27} color={colors.primary} /></View><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.emptyText}>{message}</Text></View>;
}

export function formatDuration(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return minutes > 0 ? `${minutes} min ${remainder.toString().padStart(2, '0')} s` : `${remainder} s`;
}

export const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  screen: { padding: 20, paddingBottom: 34, gap: 18 },
  card: { backgroundColor: colors.surface, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: colors.border, shadowColor: '#143B59', shadowOpacity: 0.045, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 2, gap: 10 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  pageTitle: { fontSize: 25, fontWeight: '800', color: colors.text, letterSpacing: -0.6 },
  subtitle: { marginTop: 4, color: colors.secondary, fontSize: 13, lineHeight: 19 },
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { fontSize: 16, color: colors.text, fontWeight: '800' },
  button: { minHeight: 48, paddingHorizontal: 18, paddingVertical: 13, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  buttonText: { fontSize: 14, fontWeight: '800' },
  badge: { borderRadius: 99, paddingVertical: 5, paddingHorizontal: 10, alignSelf: 'flex-start' },
  badgeText: { fontSize: 11, fontWeight: '800' },
  statCard: { flex: 1, minWidth: 135, padding: 14, gap: 5 },
  statIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 5 },
  statValue: { color: colors.text, fontWeight: '800', fontSize: 22 },
  statLabel: { color: colors.secondary, fontSize: 12, fontWeight: '700' },
  statDetail: { color: colors.muted, fontSize: 10 },
  progressTrack: { height: 9, backgroundColor: '#E7F0F6', borderRadius: 99, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 99 },
  emptyState: { alignItems: 'center', paddingVertical: 28, paddingHorizontal: 20, gap: 8 },
  emptyIcon: { height: 58, width: 58, borderRadius: 20, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  emptyTitle: { fontWeight: '800', color: colors.text, fontSize: 16 },
  emptyText: { color: colors.secondary, textAlign: 'center', fontSize: 13, lineHeight: 19 },
});
