import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { AppContextValue, BrushingSession, CartEntry, Order, ReminderSettings, UserProfile } from '@/types';
import { backendEnabled, supabase } from '@/services/auth/supabase';
import {
  defaultCart, defaultProfile, defaultReminders, insertOrder, insertSession,
  listOrders, listSessions, readConfig, writeConfig,
} from '@/services/database/database';
import { loadSecureProfile, saveSecureProfile } from '@/services/database/secureProfile';
import { getProduct } from '@/constants/products';

const AppContext = createContext<AppContextValue | null>(null);
const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

export function AppProvider({ children }: React.PropsWithChildren) {
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [sessions, setSessions] = useState<BrushingSession[]>([]);
  const [cart, setCart] = useState<CartEntry[]>(defaultCart);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reminders, setReminders] = useState<ReminderSettings>(defaultReminders);
  const [cloudUserId, setCloudUserId] = useState<string | null>(null);
  const [ownerId, setOwnerId] = useState('local');
  const workspaceVersion = useRef(0);

  const loadWorkspace = async (nextOwnerId: string) => {
    const version = ++workspaceVersion.current;
    const [savedProfile, savedCart, savedReminders, savedSessions, savedOrders] = await Promise.all([
      loadSecureProfile(nextOwnerId),
      readConfig<CartEntry[]>(`cart:${nextOwnerId}`, defaultCart),
      readConfig<ReminderSettings>(`reminders:${nextOwnerId}`, defaultReminders),
      listSessions(nextOwnerId),
      listOrders(nextOwnerId),
    ]);
    if (version !== workspaceVersion.current) return;
    setOwnerId(nextOwnerId);
    setProfile(savedProfile);
    setCart(savedCart);
    setReminders(savedReminders);
    setSessions(savedSessions);
    setOrders(savedOrders);
  };

  useEffect(() => {
    let mounted = true;
    const boot = async () => {
      try {
        if (!mounted) return;
        await loadWorkspace('local');
      } catch (error) {
        console.error('Falha ao iniciar banco local:', error);
      } finally {
        if (mounted) setReady(true);
      }
    };
    void boot();

    const authSubscription = supabase?.auth.onAuthStateChange((_event, session) => {
      if (mounted) {
        const nextOwnerId = session?.user.id ?? 'local';
        setCloudUserId(session?.user.id ?? null);
        void loadWorkspace(nextOwnerId).then(async () => {
          if (session?.user) {
            const displayName = session.user.user_metadata?.full_name;
            const saved = await loadSecureProfile(nextOwnerId);
            const next = {
              ...saved,
              name: typeof displayName === 'string' && displayName.trim() ? displayName : saved.name,
              email: session.user.email ?? saved.email,
            };
            setProfile(next);
            await saveSecureProfile(next, nextOwnerId);
          }
        }).catch((error) => console.warn('Não foi possível carregar os dados da conta:', error));
      }
    }).data.subscription;

    return () => {
      mounted = false;
      authSubscription?.unsubscribe();
    };
  }, []);

  const updateProfile = async (data: Partial<UserProfile>) => {
    const next = { ...profile, ...data };
    setProfile(next);
    await saveSecureProfile(next, ownerId);
  };

  const recordSession = async (durationSeconds: number) => {
    if (!Number.isFinite(durationSeconds) || durationSeconds < 1) throw new Error('Duração da escovação inválida.');
    const session: BrushingSession = {
      id: makeId(),
      occurredAt: new Date().toISOString(),
      durationSeconds: Math.round(durationSeconds),
      source: 'manual',
      note: 'Registro manual pelo cronômetro do aplicativo; nenhum sensor foi consultado.',
    };
    await insertSession(session, ownerId);
    setSessions((current) => [session, ...current]);
    if (supabase && cloudUserId) {
      const { error } = await supabase.from('brushing_sessions').insert({
        id: session.id,
        user_id: cloudUserId,
        occurred_at: session.occurredAt,
        duration_seconds: session.durationSeconds,
        source: session.source,
        note: session.note,
      });
      if (error) console.warn('Sessão salva no aparelho, mas não sincronizada com a nuvem:', error.message);
    }
  };

  const persistCart = async (next: CartEntry[]) => {
    setCart(next);
    await writeConfig(`cart:${ownerId}`, next);
  };

  const addToCart = async (productId: string) => {
    if (!getProduct(productId)) throw new Error('Produto não encontrado.');
    const existing = cart.find((item) => item.productId === productId);
    const next = existing
      ? cart.map((item) => item.productId === productId ? { ...item, quantity: item.quantity + 1 } : item)
      : [...cart, { productId, quantity: 1 }];
    await persistCart(next);
  };

  const updateCartQuantity = async (productId: string, quantity: number) => {
    const next = quantity <= 0
      ? cart.filter((item) => item.productId !== productId)
      : cart.map((item) => item.productId === productId ? { ...item, quantity: Math.min(99, Math.floor(quantity)) } : item);
    await persistCart(next);
  };

  const checkout = async () => {
    if (cart.length === 0) throw new Error('Adicione ao menos um produto ao carrinho.');
    const lines = cart.map((entry) => {
      const product = getProduct(entry.productId);
      if (!product) throw new Error('Um produto do carrinho não está mais disponível.');
      return { productId: product.id, name: product.name, unitPrice: product.price, quantity: entry.quantity };
    });
    const order: Order = {
      id: `OR-${Date.now().toString().slice(-8)}`,
      createdAt: new Date().toISOString(),
      items: lines,
      total: lines.reduce((sum, line) => sum + line.unitPrice * line.quantity, 0),
      status: 'Aguardando integração de pagamento',
    };
    await insertOrder(order, ownerId);
    setOrders((current) => [order, ...current]);
    await persistCart([]);
    return order;
  };

  const updateReminders = async (data: ReminderSettings) => {
    setReminders(data);
    await writeConfig(`reminders:${ownerId}`, data);
  };

  const signIn = async (email: string, password: string) => {
    if (!supabase) throw new Error('Configure as variáveis do Supabase no arquivo .env para habilitar contas online.');
    const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) throw error;
    setCloudUserId(data.user?.id ?? null);
    if (data.user?.id) {
      await loadWorkspace(data.user.id);
      const saved = await loadSecureProfile(data.user.id);
      const next = { ...saved, email: data.user.email ?? email.trim() };
      setProfile(next);
      await saveSecureProfile(next, data.user.id);
    }
  };

  const signUp = async (name: string, email: string, password: string) => {
    if (!supabase) throw new Error('Configure as variáveis do Supabase no arquivo .env para habilitar cadastro online.');
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(), password,
      options: { data: { full_name: name.trim() } },
    });
    if (error) throw error;
    if (data.session?.user.id) {
      setCloudUserId(data.session.user.id);
      await loadWorkspace(data.session.user.id);
      const saved = await loadSecureProfile(data.session.user.id);
      const next = { ...saved, name: name.trim(), email: email.trim() };
      setProfile(next);
      await saveSecureProfile(next, data.session.user.id);
    } else {
      await updateProfile({ name: name.trim(), email: email.trim() });
    }
  };

  const resetPassword = async (email: string) => {
    if (!supabase) throw new Error('Configure as variáveis do Supabase para habilitar recuperação de senha.');
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim());
    if (error) throw error;
  };

  const signOut = async () => {
    if (supabase) {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    }
    setCloudUserId(null);
    await loadWorkspace('local');
  };

  const value = useMemo<AppContextValue>(() => ({
    ready, profile, sessions, cart, orders, reminders, backendEnabled, cloudUserId,
    updateProfile, recordSession, addToCart, updateCartQuantity, checkout,
    updateReminders, signIn, signUp, resetPassword, signOut,
  }), [ready, profile, sessions, cart, orders, reminders, cloudUserId, ownerId]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp deve ser utilizado dentro de AppProvider.');
  return context;
}
