import type { Product } from '@/types';

export const PRODUCTS: Product[] = [
  {
    id: 'brush',
    name: 'Escova Inteligente ORALSCLAN',
    description: 'Escova com sensores ópticos e indicadores luminosos. A conexão com o aplicativo depende do hardware final.',
    price: 250,
    icon: 'toothbrush-electric',
    accent: '#DFF2FF',
  },
  {
    id: 'paste',
    name: 'Pasta Clareadora ORALSCLAN',
    description: 'Pasta com flúor para auxiliar na remoção de manchas superficiais.',
    price: 90,
    icon: 'bottle-tonic-plus-outline',
    accent: '#E7F7F0',
  },
  {
    id: 'kit',
    name: 'Kit Completo ORALSCLAN',
    description: 'Escova inteligente + pasta clareadora em um único kit.',
    price: 354.99,
    icon: 'gift-outline',
    accent: '#F1ECFF',
  },
];

export const getProduct = (id: string) => PRODUCTS.find((product) => product.id === id);
export const currency = (value: number) =>
  value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
