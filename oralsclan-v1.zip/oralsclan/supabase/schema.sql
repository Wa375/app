-- ORALSCLAN: schema inicial para Supabase/PostgreSQL.
-- Execute este arquivo no SQL Editor do projeto Supabase.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.brushing_sessions (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  occurred_at timestamptz not null default now(),
  duration_seconds integer not null check (duration_seconds > 0 and duration_seconds <= 7200),
  source text not null default 'manual' check (source in ('manual', 'device')),
  note text
);

create index if not exists brushing_sessions_user_date_idx
  on public.brushing_sessions(user_id, occurred_at desc);

create table if not exists public.orders (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'pending_payment',
  payment_provider_reference text
);

alter table public.profiles enable row level security;
alter table public.brushing_sessions enable row level security;
alter table public.orders enable row level security;

-- Cada pessoa só lê/altera o próprio perfil e seus registros.
drop policy if exists "profile_select_own" on public.profiles;
create policy "profile_select_own" on public.profiles
  for select to authenticated using (auth.uid() = id);

drop policy if exists "profile_insert_own" on public.profiles;
create policy "profile_insert_own" on public.profiles
  for insert to authenticated with check (auth.uid() = id);

drop policy if exists "profile_update_own" on public.profiles;
create policy "profile_update_own" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "sessions_select_own" on public.brushing_sessions;
create policy "sessions_select_own" on public.brushing_sessions
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "sessions_insert_own" on public.brushing_sessions;
create policy "sessions_insert_own" on public.brushing_sessions
  for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "sessions_delete_own" on public.brushing_sessions;
create policy "sessions_delete_own" on public.brushing_sessions
  for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "orders_select_own" on public.orders;
create policy "orders_select_own" on public.orders
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "orders_insert_own" on public.orders;
create policy "orders_insert_own" on public.orders
  for insert to authenticated with check (auth.uid() = user_id);

-- Nota: a primeira versão salva pedidos localmente. A tabela remota está preparada,
-- mas não há integração de pagamento nem envio de pedidos ao backend ainda.
