# ORALSCLAN — aplicativo inteligente de saúde bucal

Primeira versão funcional do aplicativo ORALSCLAN, construída com React Native, Expo e TypeScript.

## O que esta versão já faz

- Navegação inferior com Início, Escovação, Histórico, Loja e Perfil.
- Cronômetro de escovação manual e gravação local de data, horário e duração.
- Histórico com filtros de hoje, últimos 7 dias e últimos 30 dias, além de gráfico de frequência.
- Loja com os três produtos e preços fornecidos no escopo.
- Carrinho persistente, controle de quantidades, resumo, finalização demonstrativa e histórico de pedidos.
- Perfil local editável, com informações básicas guardadas no armazenamento seguro do sistema (SecureStore).
- Lembretes diários locais de manhã e à noite, com horários configuráveis.
- Central de ajuda e avisos de responsabilidade odontológica.
- Tela de escova com estado desconectado explícito e contrato isolado para integração BLE futura.
- Análise por regiões em modo demonstrativo, claramente identificada como simulação.
- Integração opcional com Supabase Auth e sincronização de novas sessões autenticadas.
- Banco SQL do Supabase com Row Level Security (RLS).

## O que depende de configuração ou hardware

1. **Conta online:** exige projeto Supabase, variáveis `.env` e execução de `supabase/schema.sql` no SQL Editor.
2. **Bluetooth real:** depende da escova física, firmware, UUIDs de serviços/características GATT, formato dos pacotes e implementação do adaptador BLE. Esta versão não finge conectar.
3. **Pagamento e comércio:** carrinho e pedidos são locais. Não há gateway, estoque, frete, emissão fiscal ou envio real.
4. **Imagens comerciais:** os ícones são ilustrações vetoriais de interface. Fotografias oficiais dos produtos devem ser adicionadas quando estiverem disponíveis.
5. **Suporte:** o canal de contato precisa ser configurado antes da publicação.

## Requisitos para executar

- Node.js 22.13 ou superior.
- npm.
- Android com Expo Go para testar os recursos compatíveis, ou emulador Android configurado.
- Para recursos que exigem código nativo próprio (como BLE), será necessário um development build.

## Instalação no Windows

1. Extraia o ZIP para uma pasta, por exemplo `C:\Projetos\oralsclan`.
2. Abra essa pasta no Terminal/PowerShell.
3. Instale as dependências:

   ```powershell
   npm install
   npx expo install --fix
   ```

4. Inicie o servidor:

   ```powershell
   npx expo start
   ```

5. Instale o aplicativo **Expo Go** no celular Android, conecte celular e computador à mesma rede Wi-Fi e leia o QR Code exibido no terminal.

Se a rede local bloquear a descoberta, tente `npx expo start --tunnel`.

## Configurar Supabase (opcional)

1. Crie um projeto no Supabase.
2. Copie a Project URL e a Publishable Key do painel Connect.
3. Copie `.env.example` para `.env` e preencha:

   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
   EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sua_publishable_key
   ```

4. No SQL Editor do Supabase, execute todo o conteúdo de `supabase/schema.sql`.
5. Reinicie o Expo para carregar as variáveis de ambiente.
6. Abra Perfil → Entrar ou criar conta.

A Publishable Key pode ser incluída no aplicativo cliente quando as políticas RLS estão corretamente configuradas. **Nunca coloque `service_role`, senha do banco ou outros segredos administrativos em variáveis `EXPO_PUBLIC_`.**

Sem `.env`, o app continua funcionando em modo local e não apresenta a autenticação online como ativa.

## Estrutura

```text
app/                         Rotas e telas do Expo Router
  (tabs)/                    As cinco abas principais
  analysis.tsx                Mapa ilustrativo de regiões
  device.tsx                  Estado e preparação BLE
  cart.tsx / checkout.tsx     Carrinho e finalização local
  orders.tsx                  Histórico de pedidos
  reminders.tsx               Preferências de notificações
  account.tsx                 Login, cadastro e recuperação Supabase
  support.tsx                 FAQ e avisos
src/
  components/                 Componentes visuais reutilizáveis
  context/                    Estado compartilhado do aplicativo
  constants/                  Catálogo e dados fixos
  services/database/          SQLite e persistência
  services/auth/              Cliente Supabase
  services/bluetooth/         Contrato BLE isolado
  services/notifications/     Agendamento local
  theme/                      Paleta visual
  types/                      Tipos TypeScript
supabase/schema.sql           Tabelas e políticas RLS
```

## Modelo de dados e privacidade

- Sessões, carrinho, lembretes e pedidos do modo local ficam no SQLite do aparelho; o nome/e-mail do perfil ficam no SecureStore do sistema.
- Senhas não são armazenadas pelo app; quando Supabase está habilitado, autenticação e recuperação são delegadas ao Supabase Auth. O perfil básico local usa SecureStore.
- Novas sessões de usuários autenticados são enviadas ao backend além de serem salvas localmente. Se a sincronização falhar, o registro local permanece.
- A primeira versão não sincroniza ainda perfil, carrinho ou pedidos para a nuvem. O banco SQLite local não usa SQLCipher nesta versão; antes de produção, avalie criptografia de dados locais e política de retenção.
- Antes de publicar, implemente política de privacidade, consentimento, exclusão/exportação de dados, canal oficial de suporte, revisão jurídica da LGPD e testes de segurança.

## Critérios de interpretação de saúde

O ORALSCLAN não é um dispositivo médico nesta versão. O aplicativo não diagnostica, não confirma tártaro nem substitui avaliação de um cirurgião-dentista. Os exemplos de cores e regiões são dados ilustrativos e jamais devem ser apresentados como leitura real dos sensores.

## Testes

```powershell
npm run typecheck
```

Também teste manualmente: abrir abas, iniciar/finalizar uma sessão, reiniciar o app e conferir o histórico, adicionar/remover produtos, finalizar um pedido, salvar horários de lembrete e usar o modo demonstrativo da análise.
