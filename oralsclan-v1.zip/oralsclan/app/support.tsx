import React, { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Header, Screen, SectionTitle } from '@/components/ui';
import { colors } from '@/theme/colors';

const faqs = [
  { question: 'Como começo a usar o aplicativo?', answer: 'Você pode registrar uma escovação pelo cronômetro na aba Escovação. O registro contém a duração e fica salvo no aparelho.' },
  { question: 'Como conecto a escova inteligente?', answer: 'A conexão Bluetooth real ainda depende da escova física, do firmware e da definição do protocolo BLE/GATT. Nesta versão, o aplicativo não simula uma conexão.' },
  { question: 'O que significam as cores da análise?', answer: 'Verde, amarelo e vermelho são categorias ilustrativas de apresentação. Somente poderão representar dados da escova quando houver medições reais e protocolo validado.' },
  { question: 'A análise confirma placa bacteriana ou tártaro?', answer: 'Não. O aplicativo não confirma placa, tártaro ou qualquer condição odontológica. As informações futuras serão indicativas e não substituem avaliação profissional.' },
  { question: 'Como funcionam os pedidos da loja?', answer: 'O carrinho e o histórico de pedidos funcionam localmente. Não existe pagamento, envio ou integração comercial ativo nesta primeira versão.' },
  { question: 'Onde ficam meus dados?', answer: 'No modo local, histórico, perfil, carrinho e pedidos são salvos no banco SQLite do próprio aparelho. A sincronização em nuvem depende da configuração do Supabase.' },
];

export default function SupportScreen() {
  const [expanded, setExpanded] = useState<number | null>(0);
  return <Screen>
    <Header title="Ajuda e suporte" subtitle="Orientações para usar o ORALSCLAN com segurança." />
    <Card style={{ backgroundColor: colors.primaryDark, borderColor: colors.primaryDark }}>
      <Ionicons name="chatbubbles-outline" size={31} color="#C7E9FF" />
      <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '900' }}>Como podemos ajudar?</Text>
      <Text style={{ color: '#C5E4F8', fontSize: 12, lineHeight: 18 }}>Consulte as perguntas frequentes ou entre em contato com a equipe responsável pelo projeto.</Text>
      <Pressable onPress={() => Alert.alert('Suporte não configurado', 'Adicione o e-mail ou canal oficial da ORALSCLAN antes de publicar o aplicativo.')} style={{ backgroundColor: '#FFFFFF', borderRadius: 12, padding: 12, alignItems: 'center' }}><Text style={{ color: colors.primaryDark, fontWeight: '900', fontSize: 13 }}>Consultar canal de suporte</Text></Pressable>
      <Text style={{ color: '#B8D7EA', fontSize: 9 }}>O canal oficial de contato ainda precisa ser definido.</Text>
    </Card>
    <SectionTitle title="Perguntas frequentes" />
    {faqs.map((faq, index) => <Card key={faq.question} style={{ padding: 0, overflow: 'hidden', gap: 0 }}>
      <Pressable onPress={() => setExpanded(expanded === index ? null : index)} style={{ padding: 15, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Text style={{ color: colors.text, fontWeight: '800', fontSize: 13, flex: 1 }}>{faq.question}</Text>
        <Ionicons name={expanded === index ? 'chevron-up' : 'chevron-down'} size={18} color={colors.primary} />
      </Pressable>
      {expanded === index ? <View style={{ paddingHorizontal: 15, paddingBottom: 15 }}><Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 19 }}>{faq.answer}</Text></View> : null}
    </Card>)}
    <SectionTitle title="Aviso de saúde" />
    <Card>
      <View style={{ flexDirection: 'row', gap: 9, alignItems: 'center' }}><Ionicons name="medical-outline" size={23} color={colors.warning} /><Text style={{ color: colors.text, fontWeight: '900' }}>Informação importante</Text></View>
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 19 }}>O ORALSCLAN não substitui consultas odontológicas. Os sensores fornecem informações indicativas, não confirmam a presença de tártaro e não realizam diagnóstico médico ou odontológico. Procure um cirurgião-dentista para avaliação da saúde bucal.</Text>
    </Card>
    <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center' }}>ORALSCLAN · Central de ajuda v1.0.0</Text>
  </Screen>;
}
