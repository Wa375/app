import React, { useState } from 'react';
import { Alert, Text, TextInput, View, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Badge, Button, Card, Header, Screen } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

type Mode = 'login' | 'signup' | 'recovery';

export default function AccountScreen() {
  const { backendEnabled, signIn, signUp, resetPassword } = useApp();
  const [mode, setMode] = useState<Mode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  const submit = async () => {
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) { Alert.alert('E-mail inválido', 'Informe um e-mail válido.'); return; }
    if (mode !== 'recovery' && password.length < 8) { Alert.alert('Senha inválida', 'Use uma senha com pelo menos 8 caracteres.'); return; }
    if (mode === 'signup' && !name.trim()) { Alert.alert('Nome obrigatório', 'Informe seu nome.'); return; }
    setBusy(true);
    try {
      if (mode === 'login') { await signIn(email, password); Alert.alert('Login realizado', 'Sua sessão online está ativa.'); router.replace('/(tabs)/profile'); }
      if (mode === 'signup') { await signUp(name, email, password); Alert.alert('Cadastro enviado', 'Caso a confirmação de e-mail esteja ativa no Supabase, verifique sua caixa de entrada.'); router.replace('/(tabs)/profile'); }
      if (mode === 'recovery') { await resetPassword(email); Alert.alert('Solicitação enviada', 'Confira seu e-mail para continuar a recuperação.'); setMode('login'); }
    } catch (error) { Alert.alert('Não foi possível concluir', error instanceof Error ? error.message : 'Verifique os dados e tente novamente.'); }
    finally { setBusy(false); }
  };

  return <Screen>
    <Header title="Conta ORALSCLAN" subtitle="Entre para habilitar a autenticação e a sincronização online." />
    {!backendEnabled ? <Card style={{ backgroundColor: '#FFF8E8', borderColor: '#F4E0B4' }}>
      <Badge label="BACKEND NÃO CONFIGURADO" tone="yellow" />
      <Text style={{ color: '#895B17', fontSize: 12, lineHeight: 18 }}>O aplicativo está funcionando em modo local. Para ativar cadastro, login e recuperação de senha, crie um projeto Supabase e preencha as variáveis EXPO_PUBLIC_SUPABASE_URL e EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY no arquivo .env. Não existe login falso neste modo.</Text>
    </Card> : null}
    <Card>
      <View style={{ flexDirection: 'row', backgroundColor: '#EAF2F7', borderRadius: 12, padding: 4, gap: 4 }}>
        <ModeButton title="Entrar" active={mode === 'login'} onPress={() => setMode('login')} />
        <ModeButton title="Criar conta" active={mode === 'signup'} onPress={() => setMode('signup')} />
      </View>
      {mode === 'signup' ? <><Text style={label}>Nome</Text><TextInput value={name} onChangeText={setName} placeholder="Seu nome" style={input} /></> : null}
      <Text style={label}>E-mail</Text><TextInput value={email} onChangeText={setEmail} placeholder="voce@email.com" autoCapitalize="none" keyboardType="email-address" style={input} />
      {mode !== 'recovery' ? <><Text style={label}>Senha</Text><TextInput value={password} onChangeText={setPassword} placeholder="Mínimo de 8 caracteres" secureTextEntry style={input} /></> : null}
      <Button title={mode === 'login' ? 'Entrar' : mode === 'signup' ? 'Criar conta' : 'Enviar recuperação'} icon="lock-closed-outline" onPress={() => void submit()} loading={busy} disabled={!backendEnabled} />
      {mode === 'login' ? <Pressable onPress={() => setMode('recovery')} style={{ alignSelf: 'center', padding: 8 }}><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 12 }}>Esqueci minha senha</Text></Pressable> : null}
      {mode === 'recovery' ? <Pressable onPress={() => setMode('login')} style={{ alignSelf: 'center', padding: 8 }}><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 12 }}>Voltar ao login</Text></Pressable> : null}
    </Card>
    <Card style={{ backgroundColor: colors.primarySoft, borderColor: '#D6EAF8' }}>
      <Text style={{ color: colors.primaryDark, fontWeight: '900' }}>Modo local continua disponível</Text>
      <Text style={{ color: '#4C718B', fontSize: 12, lineHeight: 18 }}>Você pode registrar escovações, usar o histórico, configurar lembretes e montar pedidos de demonstração sem criar uma conta online. Esses dados ficam apenas no aparelho.</Text>
    </Card>
  </Screen>;
}
function ModeButton({ title, active, onPress }: { title: string; active: boolean; onPress: () => void }) { return <Pressable onPress={onPress} style={{ flex: 1, padding: 10, borderRadius: 9, backgroundColor: active ? '#FFFFFF' : 'transparent', alignItems: 'center' }}><Text style={{ color: active ? colors.primaryDark : colors.secondary, fontSize: 12, fontWeight: '800' }}>{title}</Text></Pressable>; }
const label = { color: colors.secondary, fontSize: 12, fontWeight: '700' as const, marginBottom: 6 };
const input = { height: 47, backgroundColor: colors.background, borderRadius: 12, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 13, marginBottom: 14, color: colors.text };
