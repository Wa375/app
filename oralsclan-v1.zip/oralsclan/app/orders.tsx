import React from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Card, EmptyState, Header, Screen } from '@/components/ui';
import { currency } from '@/constants/products';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function OrdersScreen() {
  const { orders } = useApp();
  const params = useLocalSearchParams<{ created?: string }>();
  return <Screen>
    <Header title="Meus pedidos" subtitle="Pedidos criados neste aparelho." />
    {params.created ? <Card style={{ backgroundColor: colors.successSoft, borderColor: '#C6EBDD' }}><Text style={{ color: colors.success, fontWeight: '900' }}>Pedido {params.created} salvo com sucesso.</Text><Text style={{ color: '#477C66', fontSize: 12 }}>O registro é local e aguarda uma integração comercial e de pagamento.</Text></Card> : null}
    {orders.length === 0 ? <Card><EmptyState icon="receipt-outline" title="Nenhum pedido por aqui" message="Quando você finalizar um pedido de demonstração, ele aparecerá nesta página." /></Card> : orders.map((order) => <Card key={order.id}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><View style={{ flex: 1, gap: 3 }}><Text style={{ color: colors.text, fontWeight: '900' }}>{order.id}</Text><Text style={{ color: colors.secondary, fontSize: 11 }}>{new Date(order.createdAt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</Text></View><Badge label="Sem pagamento" tone="yellow" /></View>
      {order.items.map((item) => <View key={item.productId} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}><Text style={{ color: colors.secondary, fontSize: 12, flex: 1 }}>{item.quantity} × {item.name}</Text><Text style={{ color: colors.text, fontSize: 12, fontWeight: '700' }}>{currency(item.unitPrice * item.quantity)}</Text></View>)}
      <View style={{ height: 1, backgroundColor: colors.border }} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ color: colors.secondary, fontSize: 12 }}>Total</Text><Text style={{ color: colors.primaryDark, fontSize: 18, fontWeight: '900' }}>{currency(order.total)}</Text></View>
      <Text style={{ color: colors.muted, fontSize: 10 }}>Pedido local. Não foi enviado à loja nem pago.</Text>
    </Card>)}
  </Screen>;
}
