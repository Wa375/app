import React, { useState } from 'react';
import { Text, View, Pressable } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Card, Header, Screen, SectionTitle } from '@/components/ui';
import { colors } from '@/theme/colors';
import type { RegionStatus } from '@/types';

const demoRegions: { id: string; label: string; detail: string; status: RegionStatus }[] = [
  { id: 'upper-front', label: 'Superior frontal', detail: 'Exemplo ilustrativo de leitura frontal superior.', status: 'good' },
  { id: 'upper-left', label: 'Superior lado esquerdo', detail: 'Exemplo ilustrativo de região que merece atenção.', status: 'attention' },
  { id: 'upper-right', label: 'Superior lado direito', detail: 'Exemplo ilustrativo de região com prioridade visual.', status: 'priority' },
  { id: 'lower-front', label: 'Inferior frontal', detail: 'Exemplo ilustrativo de leitura frontal inferior.', status: 'good' },
  { id: 'lower-left', label: 'Inferior lado esquerdo', detail: 'Exemplo ilustrativo de região que merece atenção.', status: 'attention' },
  { id: 'lower-right', label: 'Inferior lado direito', detail: 'Exemplo ilustrativo de região com prioridade visual.', status: 'good' },
];
const statusColor: Record<RegionStatus, string> = { good: colors.success, attention: colors.warning, priority: colors.danger };
const statusBg: Record<RegionStatus, string> = { good: colors.successSoft, attention: colors.warningSoft, priority: colors.dangerSoft };
const statusLabel: Record<RegionStatus, string> = { good: 'Satisfatório', attention: 'Atenção', priority: 'Prioridade' };

export default function AnalysisScreen() {
  const params = useLocalSearchParams<{ demo?: string }>();
  const isDemo = params.demo === '1';
  const [selected, setSelected] = useState(demoRegions[0]);
  return <Screen>
    <Header title="Análise da escovação" subtitle="Visualização indicativa das regiões da arcada dentária." right={<Badge label={isDemo ? 'SIMULAÇÃO' : 'SEM DADOS'} tone={isDemo ? 'yellow' : 'grey'} />} />
    {!isDemo ? <Card>
      <EmptyAnalysis />
    </Card> : <>
      <Card style={{ backgroundColor: '#FFF8E8', borderColor: '#F5DFAE' }}>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}><Ionicons name="flask-outline" size={24} color={colors.warning} /><Text style={{ color: '#875711', fontWeight: '900', flex: 1 }}>Dados demonstrativos — não são medições reais.</Text></View>
        <Text style={{ color: '#966B2E', fontSize: 12, lineHeight: 18 }}>As cores e os estados abaixo são exemplos fictícios para demonstrar a interface. Eles não avaliam seus dentes e não foram enviados por uma escova inteligente.</Text>
      </Card>
      <SectionTitle title="Mapa ilustrativo da arcada" />
      <Card>
        <View style={{ alignItems: 'center', gap: 10 }}>
          <Text style={{ color: colors.secondary, fontSize: 11, fontWeight: '800', letterSpacing: 1 }}>ARCADA SUPERIOR</Text>
          <View style={{ flexDirection: 'row', gap: 7, justifyContent: 'center' }}>
            {demoRegions.slice(0, 3).map((region) => <RegionTile key={region.id} region={region} active={selected.id === region.id} onPress={() => setSelected(region)} />)}
          </View>
          <View style={{ height: 1, width: '85%', backgroundColor: colors.border, marginVertical: 4 }} />
          <View style={{ flexDirection: 'row', gap: 7, justifyContent: 'center' }}>
            {demoRegions.slice(3, 6).map((region) => <RegionTile key={region.id} region={region} active={selected.id === region.id} onPress={() => setSelected(region)} />)}
          </View>
          <Text style={{ color: colors.secondary, fontSize: 11, fontWeight: '800', letterSpacing: 1 }}>ARCADA INFERIOR</Text>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap', gap: 12, marginTop: 12 }}>
          <Legend color={colors.success} label="Satisfatório" /><Legend color={colors.warning} label="Atenção" /><Legend color={colors.danger} label="Prioridade" />
        </View>
      </Card>
      <SectionTitle title="Região selecionada" />
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><Text style={{ color: colors.text, fontWeight: '900', fontSize: 16 }}>{selected.label}</Text><Badge label={statusLabel[selected.status]} tone={selected.status === 'good' ? 'green' : selected.status === 'attention' ? 'yellow' : 'red'} /></View>
        <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 18 }}>{selected.detail}</Text>
      </Card>
      <SectionTitle title="Resumo por região" />
      {demoRegions.map((region) => <Pressable key={region.id} onPress={() => setSelected(region)} style={{ backgroundColor: selected.id === region.id ? '#F0F8FE' : '#FFFFFF', borderRadius: 13, borderWidth: 1, borderColor: colors.border, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: statusColor[region.status] }} /><Text style={{ flex: 1, color: colors.text, fontWeight: '700', fontSize: 12 }}>{region.label}</Text><Ionicons name="chevron-forward" size={16} color={colors.muted} />
      </Pressable>)}
    </>}
    <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center', lineHeight: 15 }}>A análise, quando disponível, será apenas indicativa e baseada nos dados efetivamente fornecidos pelos sensores. Não confirma placa, tártaro ou qualquer condição odontológica.</Text>
  </Screen>;
}

function RegionTile({ region, active, onPress }: { region: typeof demoRegions[number]; active: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={{ width: '29%', minHeight: 76, backgroundColor: statusBg[region.status], borderRadius: 15, borderWidth: active ? 2 : 1, borderColor: active ? statusColor[region.status] : '#E4EDF2', alignItems: 'center', justifyContent: 'center', padding: 5, gap: 5 }}><Ionicons name="ellipse" size={15} color={statusColor[region.status]} /><Text style={{ fontSize: 9, color: colors.text, textAlign: 'center', fontWeight: '800' }}>{region.label.replace('Superior ', '').replace('Inferior ', '')}</Text></Pressable>;
}
function Legend({ color, label }: { color: string; label: string }) { return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><View style={{ width: 8, height: 8, borderRadius: 5, backgroundColor: color }} /><Text style={{ color: colors.secondary, fontSize: 10 }}>{label}</Text></View>; }
function EmptyAnalysis() { return <View style={{ alignItems: 'center', paddingVertical: 18, gap: 9 }}><Ionicons name="analytics-outline" size={42} color={colors.muted} /><Text style={{ color: colors.text, fontWeight: '900', fontSize: 16 }}>Nenhuma análise disponível</Text><Text style={{ color: colors.secondary, textAlign: 'center', fontSize: 12, lineHeight: 18 }}>A escova ainda não enviou dados. Conecte um dispositivo compatível ou abra o modo de demonstração pelo painel inicial.</Text></View>; }
