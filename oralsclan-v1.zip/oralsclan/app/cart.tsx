import React from 'react';
import { Alert, Text, View, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, EmptyState, Header, Screen, SectionTitle } from '@/components/ui';
import { currency, getProduct } from '@/constants/products';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function CartScreen() {
  const { cart, updateCartQuantity } = useApp();
  const router = useRouter();
  const lines = cart.map((entry) => ({ entry, product: getProduct(entry.productId) })).filter((line) => line.product);
  const total = lines.reduce((sum, line) => sum + (line.product?.price ?? 0) * line.entry.quantity, 0);
  const update = async (id: string, quantity: number) => {
    try { await updateCartQuantity(id, quantity); } catch { Alert.alert('Erro', 'Não foi possível atualizar o carrinho.'); }
  };
  return <Screen>
    <Header title="Carrinho" subtitle="Confira os produtos antes de finalizar." right={<Badge label={`${cart.reduce((s, i) => s + i.quantity, 0)} itens`} tone="blue" />} />
    {lines.length === 0 ? <Card><EmptyState icon="cart-outline" title="Seu carrinho está vazio" message="Visite a loja e adicione os produtos ORALSCLAN que deseja conhecer." /><Button title="Ir para a loja" icon="bag-outline" onPress={() => router.push('/(tabs)/store')} /></Card> : <>
      {lines.map(({ entry, product }) => product ? <Card key={product.id}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12 }}>
          <View style={{ width: 50, height: 50, borderRadius: 15, backgroundColor: product.accent, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="cube-outline" size={24} color={colors.primaryDark} /></View>
          <View style={{ flex: 1, gap: 4 }}><Text style={{ color: colors.text, fontWeight: '900', fontSize: 13 }}>{product.name}</Text><Text style={{ color: colors.primary, fontWeight: '900' }}>{currency(product.price)}</Text></View>
          <Text style={{ color: colors.text, fontWeight: '900' }}>{currency(product.price * entry.quantity)}</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 14 }}>
          <Pressable onPress={() => void update(product.id, entry.quantity - 1)} style={quantityButton}><Ionicons name="remove" size={18} color={colors.primary} /></Pressable>
          <Text style={{ color: colors.text, fontWeight: '900' }}>{entry.quantity}</Text>
          <Pressable onPress={() => void update(product.id, entry.quantity + 1)} style={quantityButton}><Ionicons name="add" size={18} color={colors.primary} /></Pressable>
          <Pressable onPress={() => void update(product.id, 0)}><Ionicons name="trash-outline" size={19} color={colors.danger} /></Pressable>
        </View>
      </Card> : null)}
      <SectionTitle title="Resumo do pedido" />
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: colors.secondary, fontSize: 13 }}>Subtotal</Text><Text style={{ color: colors.text, fontWeight: '800' }}>{currency(total)}</Text></View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: colors.secondary, fontSize: 13 }}>Frete</Text><Text style={{ color: colors.secondary, fontSize: 12 }}>A definir</Text></View>
        <View style={{ height: 1, backgroundColor: colors.border }} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: colors.text, fontWeight: '900' }}>Total dos produtos</Text><Text style={{ color: colors.primaryDark, fontWeight: '900', fontSize: 19 }}>{currency(total)}</Text></View>
        <Button title="Continuar para finalizar" icon="arrow-forward" onPress={() => router.push('/checkout')} />
        <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center' }}>Sem pagamento real configurado. O pedido será salvo localmente.</Text>
      </Card>
    </>}
  </Screen>;
}
const quantityButton = { width: 30, height: 30, borderRadius: 10, borderWidth: 1, borderColor: colors.border, alignItems: 'center' as const, justifyContent: 'center' as const, backgroundColor: '#F7FBFE' };
