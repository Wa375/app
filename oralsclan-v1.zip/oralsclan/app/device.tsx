import React from 'react';
import { Alert, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, Header, Screen, SectionTitle } from '@/components/ui';
import { BLE_INTEGRATION_STATUS, scanAndConnect } from '@/services/bluetooth/bleClient';
import { colors } from '@/theme/colors';

export default function DeviceScreen() {
  const router = useRouter();
  const tryConnect = async () => {
    const result = await scanAndConnect();
    if (!result.connected) Alert.alert('Bluetooth ainda não configurado', 'A busca BLE real depende do hardware, firmware e UUIDs GATT da escova. Nenhuma conexão foi simulada.');
  };
  return <Screen>
    <Header title="Minha escova" subtitle="Gerencie a conexão e consulte o estado do dispositivo." />
    <Card style={{ alignItems: 'center', paddingVertical: 24 }}>
      <View style={{ width: 94, height: 94, borderRadius: 30, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="bluetooth" size={48} color={colors.primary} /></View>
      <Text style={{ color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 13 }}>ORALSCLAN Smart Brush</Text>
      <Badge label="DESCONECTADA" tone="grey" />
      <Text style={{ color: colors.secondary, fontSize: 12, textAlign: 'center', lineHeight: 18, marginTop: 5 }}>Nenhuma escova física foi localizada ou conectada a este aplicativo.</Text>
      <View style={{ width: '100%', marginTop: 12 }}><Button title="Tentar conectar" icon="bluetooth" onPress={() => void tryConnect()} /></View>
    </Card>
    <SectionTitle title="Estado do dispositivo" />
    <Card>
      <DeviceRow label="Conexão Bluetooth" value="Desconectada" tone="grey" />
      <DeviceRow label="Bateria" value="Indisponível" tone="grey" />
      <DeviceRow label="Última sincronização" value="Nunca" tone="grey" />
      <DeviceRow label="Sensores ópticos" value="Sem leitura" tone="yellow" />
    </Card>
    <SectionTitle title="Integração BLE" />
    <Card>
      <Badge label="PREPARAÇÃO DE SOFTWARE" tone="blue" />
      <Text style={{ color: colors.text, fontWeight: '800' }}>Camada de conexão criada</Text>
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 19 }}>{BLE_INTEGRATION_STATUS}</Text>
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 19 }}>Para ativar, será necessário definir o nome anunciado pela escova, serviço GATT, características de leitura/escrita, formato dos pacotes e mecanismo de autenticação do dispositivo.</Text>
    </Card>
    <SectionTitle title="Conhecer a análise" />
    <Card>
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 18 }}>Veja como o aplicativo apresentará regiões em um exemplo didático. Os resultados serão identificados como simulados e não representam uma leitura da sua escova.</Text>
      <Button title="Abrir demonstração" icon="eye-outline" variant="secondary" onPress={() => router.push({ pathname: '/analysis', params: { demo: '1' } })} />
    </Card>
    <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center' }}>Não há dados de bateria, sensores ou conexão disponíveis enquanto a escova física não estiver integrada.</Text>
  </Screen>;
}

function DeviceRow({ label, value, tone }: { label: string; value: string; tone: 'grey' | 'yellow' }) {
  return <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 7 }}><Text style={{ color: colors.secondary, fontSize: 12 }}>{label}</Text><Badge label={value} tone={tone} /></View>;
}
