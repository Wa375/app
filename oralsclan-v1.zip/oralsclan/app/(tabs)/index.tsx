import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, Header, SectionTitle, Button, Badge, StatCard, ProgressBar, formatDuration } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function DashboardScreen() {
  const { profile, sessions } = useApp();
  const router = useRouter();
  const today = new Date().toDateString();
  const todaysSessions = sessions.filter((item) => new Date(item.occurredAt).toDateString() === today);
  const totalSeconds = todaysSessions.reduce((sum, item) => sum + item.durationSeconds, 0);
  const progress = Math.min(100, todaysSessions.length / 2 * 100);
  const last = sessions[0];
  const activityDays = new Set(sessions.map((item) => new Date(item.occurredAt).toDateString()));
  let streak = 0;
  const streakCursor = new Date();
  if (!activityDays.has(streakCursor.toDateString())) streakCursor.setDate(streakCursor.getDate() - 1);
  while (activityDays.has(streakCursor.toDateString())) { streak += 1; streakCursor.setDate(streakCursor.getDate() - 1); }

  return <Screen>
    <Header title={`Olá, ${profile.name || 'Visitante'}!`} subtitle="Seu cuidado diário começa com pequenos hábitos." right={<View style={{ backgroundColor: colors.primarySoft, width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="sparkles" size={22} color={colors.primary} /></View>} />

    <Card style={{ backgroundColor: colors.primaryDark, borderColor: colors.primaryDark, padding: 20, overflow: 'hidden' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View style={{ flex: 1, gap: 8 }}>
          <Badge label="SEU RESUMO DE HOJE" tone="green" />
          <Text style={{ color: '#FFFFFF', fontSize: 22, fontWeight: '800', lineHeight: 28 }}>Um sorriso saudável começa na rotina.</Text>
          <Text style={{ color: '#C5E4F8', fontSize: 12, lineHeight: 18 }}>Acompanhe suas escovações e construa consistência todos os dias.</Text>
        </View>
        <Ionicons name="happy-outline" size={54} color="#B9E6FF" />
      </View>
      <View style={{ marginTop: 18, gap: 8 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: '#D7EEFC', fontSize: 12, fontWeight: '700' }}>Meta diária</Text>
          <Text style={{ color: '#FFFFFF', fontSize: 12, fontWeight: '800' }}>{todaysSessions.length}/2 escovações</Text>
        </View>
        <ProgressBar value={progress} color="#69D8A5" />
        <Text style={{ color: '#C5E4F8', fontSize: 11 }}>Referência geral: duas escovações ao dia.</Text>
      </View>
      <View style={{ marginTop: 16 }}>
        <Button title="Iniciar escovação" icon="play" onPress={() => router.push('/(tabs)/brushing')} variant="secondary" />
      </View>
    </Card>

    <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
      <StatCard label="Escovações hoje" value={`${todaysSessions.length}`} detail="Meta de referência: 2" icon="water" />
      <StatCard label="Tempo total" value={formatDuration(totalSeconds)} detail="Registrado manualmente" icon="timer-outline" accent={colors.success} />
    </View>

    <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
      <StatCard label="Sequência atual" value={`${streak} ${streak === 1 ? 'dia' : 'dias'}`} detail="Dias consecutivos com registro" icon="flame-outline" accent={colors.warning} />
      <StatCard label="Total de sessões" value={`${sessions.length}`} detail="Desde o primeiro registro" icon="trophy-outline" accent={colors.primary} />
    </View>

    <SectionTitle title="Conquistas" />
    <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      <View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: sessions.length > 0 ? colors.successSoft : '#EEF3F6', alignItems: 'center', justifyContent: 'center' }}><Ionicons name="medal-outline" size={21} color={sessions.length > 0 ? colors.success : colors.muted} /></View>
      <View style={{ flex: 1, gap: 2 }}><Text style={{ color: colors.text, fontWeight: '800', fontSize: 12 }}>Primeiro registro</Text><Text style={{ color: colors.secondary, fontSize: 11 }}>{sessions.length > 0 ? 'Conquista desbloqueada' : 'Registre sua primeira escovação'}</Text></View>
      <Badge label={sessions.length > 0 ? 'Concluída' : 'Bloqueada'} tone={sessions.length > 0 ? 'green' : 'grey'} />
    </Card>

    <SectionTitle title="Minha escova" />
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ height: 46, width: 46, borderRadius: 15, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="bluetooth" size={24} color={colors.primary} /></View>
        <View style={{ flex: 1, gap: 3 }}>
          <Text style={{ color: colors.text, fontWeight: '800' }}>Escova não conectada</Text>
          <Text style={{ color: colors.secondary, fontSize: 12 }}>Nenhum dado de sensor recebido.</Text>
        </View>
        <Badge label="Offline" tone="grey" />
      </View>
      <Link href="/device" asChild><Pressable style={{ paddingTop: 5, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 13 }}>Configurar dispositivo</Text><Ionicons name="chevron-forward" size={18} color={colors.primary} /></Pressable></Link>
    </Card>

    <SectionTitle title="Última escovação" />
    <Card>
      {last ? <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ backgroundColor: colors.successSoft, width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="checkmark-circle" color={colors.success} size={23} /></View>
        <View style={{ flex: 1, gap: 3 }}><Text style={{ color: colors.text, fontWeight: '800' }}>{new Date(last.occurredAt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</Text><Text style={{ color: colors.secondary, fontSize: 12 }}>{formatDuration(last.durationSeconds)} · registro manual</Text></View>
        <Badge label="Salvo" tone="green" />
      </View> : <Text style={{ color: colors.secondary, fontSize: 13 }}>Você ainda não registrou uma escovação. Use o cronômetro para começar.</Text>}
      <Link href="/(tabs)/history" asChild><Pressable style={{ marginTop: 5 }}><Text style={{ color: colors.primary, fontSize: 13, fontWeight: '800' }}>Ver histórico completo →</Text></Pressable></Link>
    </Card>

    <SectionTitle title="Análise das regiões" />
    <Card style={{ gap: 8 }}>
      <Badge label="SEM LEITURA DE SENSOR" tone="yellow" />
      <Text style={{ color: colors.text, fontWeight: '700' }}>Ainda não há uma leitura real da escova.</Text>
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 18 }}>Você pode visualizar uma demonstração ilustrativa, identificada como dados simulados, sem relação com seus dentes.</Text>
      <Link href={{ pathname: "/analysis", params: { demo: "1" } }} asChild><Pressable style={{ backgroundColor: colors.primarySoft, padding: 12, borderRadius: 12, alignItems: 'center' }}><Text style={{ color: colors.primaryDark, fontWeight: '800', fontSize: 13 }}>Ver análise demonstrativa</Text></Pressable></Link>
    </Card>

    <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center', lineHeight: 15 }}>ORALSCLAN não substitui consultas odontológicas. As informações do aplicativo não constituem diagnóstico.</Text>
  </Screen>;
}
