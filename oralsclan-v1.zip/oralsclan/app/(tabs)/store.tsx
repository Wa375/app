import React from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { Link } from 'expo-router';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, Header, Screen, SectionTitle } from '@/components/ui';
import { PRODUCTS, currency } from '@/constants/products';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function StoreScreen() {
  const { addToCart, cart } = useApp();
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const add = async (id: string, name: string) => {
    try { await addToCart(id); Alert.alert('Adicionado ao carrinho', `${name} foi adicionado.`); }
    catch (error) { Alert.alert('Erro', error instanceof Error ? error.message : 'Não foi possível adicionar.'); }
  };

  return <Screen>
    <Header title="Loja ORALSCLAN" subtitle="Tecnologia e cuidado para sua rotina bucal." right={<Link href="/cart" asChild><Pressable style={{ width: 44, height: 44, borderRadius: 15, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="cart-outline" size={22} color={colors.primary} /><View style={{ position: 'absolute', right: -3, top: -3, backgroundColor: colors.danger, minWidth: 17, height: 17, borderRadius: 9, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#FFFFFF', fontSize: 9, fontWeight: '900' }}>{cartCount}</Text></View></Pressable></Link>} />
    <Card style={{ backgroundColor: '#EAF6FF', borderColor: '#D9ECFA' }}>
      <Text style={{ fontSize: 11, fontWeight: '900', color: colors.primary, letterSpacing: 1 }}>ORALSCLAN ESSENTIALS</Text>
      <Text style={{ fontSize: 21, fontWeight: '900', color: colors.primaryDark }}>Seu cuidado, em outro nível.</Text>
      <Text style={{ color: '#52728B', fontSize: 12, lineHeight: 18 }}>Conheça os produtos da marca e monte seu kit de cuidados.</Text>
      <Badge label="Catálogo demonstrativo" tone="blue" />
    </Card>
    <SectionTitle title="Produtos" />
    {PRODUCTS.map((product) => <Card key={product.id} style={{ padding: 0, overflow: 'hidden', gap: 0 }}>
      <View style={{ backgroundColor: product.accent, padding: 22, alignItems: 'center', justifyContent: 'center', minHeight: 130 }}>
        <MaterialCommunityIcons name={product.icon as keyof typeof MaterialCommunityIcons.glyphMap} size={64} color={colors.primaryDark} />
        {product.id === 'kit' ? <Badge label="COMBO" tone="blue" /> : null}
      </View>
      <View style={{ padding: 16, gap: 9 }}>
        <Text style={{ color: colors.text, fontSize: 16, fontWeight: '900' }}>{product.name}</Text>
        <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 18 }}>{product.description}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={{ color: colors.primaryDark, fontSize: 21, fontWeight: '900' }}>{currency(product.price)}</Text>
          <Button title="Adicionar" icon="add" onPress={() => void add(product.id, product.name)} />
        </View>
      </View>
    </Card>)}
    <Link href="/orders" asChild><Pressable style={{ padding: 13, backgroundColor: '#FFFFFF', borderRadius: 13, borderWidth: 1, borderColor: colors.border, alignItems: 'center' }}><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 13 }}>Consultar pedidos anteriores</Text></Pressable></Link>
    <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center', lineHeight: 15 }}>Catálogo e preços cadastrados conforme a especificação do projeto. A finalização cria um pedido local; não há pagamento nem envio real configurados.</Text>
  </Screen>;
}
