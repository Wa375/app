import React, { useMemo, useState } from 'react';
import { Text, View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Card, EmptyState, Header, Screen, SectionTitle, formatDuration } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

type Period = 'today' | 'week' | 'month';

export default function HistoryScreen() {
  const { sessions } = useApp();
  const [period, setPeriod] = useState<Period>('week');
  const now = new Date();
  const filtered = useMemo(() => sessions.filter((session) => {
    const date = new Date(session.occurredAt);
    if (period === 'today') return date.toDateString() === now.toDateString();
    const days = period === 'week' ? 7 : 30;
    return date.getTime() >= now.getTime() - days * 86400000;
  }), [sessions, period]);
  const totalSeconds = filtered.reduce((total, item) => total + item.durationSeconds, 0);
  const chartDays = period === 'month' ? 14 : 7;
  const bars = Array.from({ length: chartDays }, (_, index) => {
    const date = new Date(); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() - (chartDays - index - 1));
    const count = sessions.filter((session) => new Date(session.occurredAt).toDateString() === date.toDateString()).length;
    return { label: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }), count };
  });
  const max = Math.max(2, ...bars.map((bar) => bar.count));

  return <Screen>
    <Header title="Histórico" subtitle="Acompanhe a frequência e a duração das suas sessões." />
    <View style={{ flexDirection: 'row', backgroundColor: '#EAF2F7', borderRadius: 14, padding: 4, gap: 4 }}>
      {([{ key: 'today', label: 'Hoje' }, { key: 'week', label: '7 dias' }, { key: 'month', label: '30 dias' }] as const).map((item) => <Pressable key={item.key} onPress={() => setPeriod(item.key)} style={{ flex: 1, padding: 10, alignItems: 'center', borderRadius: 11, backgroundColor: period === item.key ? '#FFFFFF' : 'transparent' }}><Text style={{ color: period === item.key ? colors.primaryDark : colors.secondary, fontSize: 12, fontWeight: '800' }}>{item.label}</Text></Pressable>)}
    </View>
    <View style={{ flexDirection: 'row', gap: 10 }}>
      <Card style={{ flex: 1 }}><Text style={{ color: colors.secondary, fontSize: 11, fontWeight: '700' }}>Sessões</Text><Text style={{ color: colors.text, fontSize: 25, fontWeight: '900' }}>{filtered.length}</Text></Card>
      <Card style={{ flex: 1 }}><Text style={{ color: colors.secondary, fontSize: 11, fontWeight: '700' }}>Tempo total</Text><Text style={{ color: colors.text, fontSize: 21, fontWeight: '900' }}>{formatDuration(totalSeconds)}</Text></Card>
    </View>
    <SectionTitle title="Frequência de escovação" />
    <Card>
      <View style={{ height: 142, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: 5, paddingTop: 8 }}>
        {bars.map((bar, index) => <View key={`${bar.label}-${index}`} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end', gap: 6, height: '100%' }}>
          <Text style={{ color: colors.secondary, fontSize: 10, fontWeight: '700' }}>{bar.count || ''}</Text>
          <View style={{ width: '70%', maxWidth: 25, height: Math.max(5, (bar.count / max) * 88), backgroundColor: bar.count >= 2 ? colors.success : colors.primary, borderRadius: 7 }} />
          <Text style={{ color: colors.muted, fontSize: 9 }}>{bar.label.slice(0, 5)}</Text>
        </View>)}
      </View>
      <Text style={{ color: colors.muted, fontSize: 10, marginTop: 3 }}>Quantidade de registros por dia. Os dados são armazenados neste aparelho.</Text>
    </Card>
    <SectionTitle title="Sessões registradas" />
    {filtered.length === 0 ? <Card><EmptyState icon="water-outline" title="Nenhuma escovação neste período" message="Quando você finalizar uma sessão pelo cronômetro, ela aparecerá aqui." /></Card> : filtered.map((session) => <Card key={session.id}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ backgroundColor: colors.primarySoft, width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="water" color={colors.primary} size={21} /></View>
        <View style={{ flex: 1, gap: 3 }}>
          <Text style={{ color: colors.text, fontWeight: '800' }}>{new Date(session.occurredAt).toLocaleDateString('pt-BR', { dateStyle: 'medium' })}</Text>
          <Text style={{ color: colors.secondary, fontSize: 12 }}>{new Date(session.occurredAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })} · {formatDuration(session.durationSeconds)}</Text>
        </View>
        <Badge label="Manual" tone="blue" />
      </View>
      <Text style={{ color: colors.muted, fontSize: 11, lineHeight: 16 }}>Sem análise de sensores. Este registro contém somente a duração.</Text>
    </Card>)}
  </Screen>;
}
