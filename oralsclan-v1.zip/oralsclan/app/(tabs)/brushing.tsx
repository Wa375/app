import React, { useEffect, useState } from 'react';
import { Alert, Text, View, Pressable } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, Header, Screen, SectionTitle, formatDuration } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function BrushingScreen() {
  const { recordSession } = useApp();
  const router = useRouter();
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!startedAt) return;
    const timer = setInterval(() => setElapsed(Math.floor((Date.now() - startedAt) / 1000)), 500);
    return () => clearInterval(timer);
  }, [startedAt]);

  const finish = async () => {
    if (elapsed < 1) {
      Alert.alert('Tempo muito curto', 'Mantenha a escovação ativa por pelo menos um segundo para registrar.');
      return;
    }
    setSaving(true);
    try {
      await recordSession(elapsed);
      setStartedAt(null);
      setElapsed(0);
      Alert.alert('Escovação registrada', 'O tempo foi salvo no histórico como registro manual. Nenhum sensor foi consultado.');
      router.push('/(tabs)/history');
    } catch (error) {
      Alert.alert('Não foi possível salvar', error instanceof Error ? error.message : 'Tente novamente.');
    } finally { setSaving(false); }
  };

  const begin = () => { setElapsed(0); setStartedAt(Date.now()); };
  const cancel = () => { setStartedAt(null); setElapsed(0); };
  const targetProgress = Math.min(100, elapsed / 120 * 100);

  return <Screen>
    <Header title="Escovação" subtitle="Registre o tempo da sua rotina de higiene bucal." right={<Badge label="Modo manual" tone="blue" />} />
    <Card style={{ alignItems: 'center', paddingVertical: 28 }}>
      <View style={{ width: 190, height: 190, borderRadius: 95, borderWidth: 10, borderColor: '#DCEFFA', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F8FCFF' }}>
        <View style={{ alignItems: 'center', gap: 3 }}>
          <Ionicons name="time-outline" color={colors.primary} size={26} />
          <Text style={{ fontSize: 36, fontWeight: '900', color: colors.primaryDark, fontVariant: ['tabular-nums'] }}>{formatDuration(elapsed)}</Text>
          <Text style={{ fontSize: 11, color: colors.secondary }}>tempo decorrido</Text>
        </View>
      </View>
      <Text style={{ fontSize: 17, color: colors.text, fontWeight: '800', marginTop: 19 }}>{startedAt ? 'Escovação em andamento' : 'Pronto para começar?'}</Text>
      <Text style={{ color: colors.secondary, fontSize: 12, textAlign: 'center', marginTop: 5, lineHeight: 18 }}>A referência de acompanhamento é de 2 minutos. O cronômetro registra somente a duração.</Text>
      <View style={{ width: '100%', gap: 8, marginTop: 18 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ fontSize: 12, color: colors.secondary }}>Progresso da referência</Text><Text style={{ fontSize: 12, color: colors.primary, fontWeight: '800' }}>{Math.round(targetProgress)}%</Text></View>
        <View style={{ height: 8, borderRadius: 99, backgroundColor: '#E6F0F6', overflow: 'hidden' }}><View style={{ height: '100%', width: `${targetProgress}%`, backgroundColor: colors.success, borderRadius: 99 }} /></View>
      </View>
      <View style={{ width: '100%', gap: 9, marginTop: 20 }}>
        {!startedAt ? <Button title="Iniciar escovação" icon="play" onPress={begin} /> : <>
          <Button title="Finalizar e salvar" icon="checkmark" onPress={finish} loading={saving} />
          <Button title="Cancelar sessão" icon="close" onPress={cancel} variant="outline" />
        </>}
      </View>
    </Card>

    <SectionTitle title="Antes de começar" />
    <Card>
      {['Divida a boca em regiões e não tenha pressa.', 'Use movimentos suaves e alcance as superfícies externas, internas e de mastigação.', 'Não compartilhe a escova e troque a cabeça conforme a orientação do fabricante.'].map((item, index) => <View key={item} style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}><View style={{ width: 24, height: 24, borderRadius: 8, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 11 }}>{index + 1}</Text></View><Text style={{ flex: 1, color: colors.secondary, fontSize: 13, lineHeight: 19 }}>{item}</Text></View>)}
    </Card>
    <SectionTitle title="Sensores da escova" />
    <Card>
      <Badge label="NÃO CONECTADOS" tone="grey" />
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 18 }}>Esta sessão é manual. Nenhuma superfície dentária foi analisada e nenhum resultado de sensor foi criado.</Text>
      <Link href="/device" asChild><Pressable><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 13 }}>Conhecer a conexão da escova →</Text></Pressable></Link>
      <Link href={{ pathname: "/analysis", params: { demo: "1" } }} asChild><Pressable><Text style={{ color: colors.primary, fontWeight: '800', fontSize: 13 }}>Abrir análise ilustrativa →</Text></Pressable></Link>
    </Card>
  </Screen>;
}
