import React, { useEffect, useState } from 'react';
import { Alert, Text, TextInput, View, Pressable } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, Header, Screen, SectionTitle } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function ProfileScreen() {
  const { profile, updateProfile, backendEnabled, cloudUserId, signOut } = useApp();
  const [name, setName] = useState(profile.name);
  const router = useRouter();
  useEffect(() => setName(profile.name), [profile.name]);
  const save = async () => {
    if (!name.trim()) { Alert.alert('Nome obrigatório', 'Digite seu nome para salvar.'); return; }
    try { await updateProfile({ name: name.trim() }); Alert.alert('Perfil atualizado', 'Seu nome foi salvo neste aparelho.'); }
    catch { Alert.alert('Erro', 'Não foi possível atualizar o perfil.'); }
  };
  const logout = () => Alert.alert('Sair da conta', 'Deseja encerrar a sessão online ou reiniciar o perfil local?', [
    { text: 'Cancelar', style: 'cancel' },
    { text: 'Sair', style: 'destructive', onPress: async () => { try { await signOut(); router.replace('/(tabs)'); } catch { Alert.alert('Erro', 'Não foi possível encerrar a sessão.'); } } },
  ]);

  return <Screen>
    <Header title="Perfil" subtitle="Suas informações e preferências." />
    <Card style={{ alignItems: 'center', paddingVertical: 22 }}>
      <View style={{ width: 76, height: 76, borderRadius: 26, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="person" size={38} color={colors.primary} /></View>
      <Text style={{ color: colors.text, fontSize: 19, fontWeight: '900', marginTop: 10 }}>{profile.name || 'Visitante'}</Text>
      <Text style={{ color: colors.secondary, fontSize: 12 }}>{profile.email || 'Perfil local neste aparelho'}</Text>
      <Badge label={cloudUserId ? 'Conta online conectada' : 'Modo local'} tone={cloudUserId ? 'green' : 'blue'} />
    </Card>
    <SectionTitle title="Dados pessoais" />
    <Card>
      <Text style={{ color: colors.secondary, fontSize: 12, fontWeight: '700' }}>Nome</Text>
      <TextInput value={name} onChangeText={setName} placeholder="Seu nome" style={{ backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 13, height: 48, color: colors.text }} />
      <Text style={{ color: colors.secondary, fontSize: 12, fontWeight: '700' }}>E-mail</Text>
      <Text style={{ color: colors.text, fontWeight: '700' }}>{profile.email || 'Não informado'}</Text>
      <Text style={{ color: colors.secondary, fontSize: 11 }}>Cadastro local: {new Date(profile.createdAt).toLocaleDateString('pt-BR')}</Text>
      <Button title="Salvar alterações" icon="save-outline" onPress={() => void save()} />
    </Card>
    <SectionTitle title="Preferências" />
    <Card style={{ gap: 0 }}>
      <MenuLink icon="notifications-outline" label="Lembretes de escovação" href="/reminders" />
      <DividerLine />
      <MenuLink icon="bluetooth-outline" label="Dispositivos conectados" href="/device" />
      <DividerLine />
      <MenuLink icon="receipt-outline" label="Meus pedidos" href="/orders" />
      <DividerLine />
      <MenuLink icon="help-circle-outline" label="Ajuda e suporte" href="/support" />
      <DividerLine />
      <MenuLink icon="shield-checkmark-outline" label="Privacidade e uso responsável" href="/support" />
    </Card>
    <SectionTitle title="Conta e segurança" />
    <Card>
      <Text style={{ color: colors.secondary, fontSize: 12, lineHeight: 18 }}>{backendEnabled ? 'O Supabase está configurado. Você pode entrar ou criar uma conta online.' : 'O app está em modo local. Para cadastro, login e recuperação de senha online, configure o Supabase no arquivo .env.'}</Text>
      <Button title={cloudUserId ? 'Gerenciar conta online' : 'Entrar ou criar conta'} icon="log-in-outline" variant="secondary" onPress={() => router.push('/account')} />
      {cloudUserId ? <Button title="Sair da conta" icon="log-out-outline" variant="outline" onPress={logout} /> : null}
    </Card>
    <Text style={{ color: colors.muted, fontSize: 10, textAlign: 'center' }}>ORALSCLAN v1.0.0 · Seus dados locais permanecem neste aparelho.</Text>
  </Screen>;
}

function MenuLink({ icon, label, href }: { icon: keyof typeof Ionicons.glyphMap; label: string; href: '/reminders' | '/device' | '/orders' | '/support' }) {
  return <Link href={href} asChild><Pressable style={{ minHeight: 50, flexDirection: 'row', alignItems: 'center', gap: 12 }}><Ionicons name={icon} size={20} color={colors.primary} /><Text style={{ flex: 1, color: colors.text, fontWeight: '700', fontSize: 13 }}>{label}</Text><Ionicons name="chevron-forward" size={17} color={colors.muted} /></Pressable></Link>;
}
function DividerLine() { return <View style={{ height: 1, backgroundColor: colors.border }} />; }
