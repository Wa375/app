import React, { useState } from 'react';
import { Alert, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Header, Screen, SectionTitle } from '@/components/ui';
import { currency, getProduct } from '@/constants/products';
import { useApp } from '@/context/AppContext';
import { colors } from '@/theme/colors';

export default function CheckoutScreen() {
  const { cart, checkout, profile, updateProfile } = useApp();
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [saving, setSaving] = useState(false);
  const router = useRouter();
  const total = cart.reduce((sum, item) => sum + (getProduct(item.productId)?.price ?? 0) * item.quantity, 0);
  const finalize = async () => {
    if (!name.trim() || !/^\S+@\S+\.\S+$/.test(email.trim())) {
      Alert.alert('Confira seus dados', 'Informe seu nome e um e-mail válido.'); return;
    }
    if (cart.length === 0) { Alert.alert('Carrinho vazio', 'Adicione produtos antes de continuar.'); router.replace('/(tabs)/store'); return; }
    setSaving(true);
    try {
      await updateProfile({ name: name.trim(), email: email.trim() });
      const order = await checkout();
      Alert.alert('Pedido salvo', 'O pedido foi registrado neste aparelho. Nenhuma cobrança ou envio foi realizado.');
      router.replace({ pathname: '/orders', params: { created: order.id } });
    } catch (error) { Alert.alert('Não foi possível finalizar', error instanceof Error ? error.message : 'Tente novamente.'); }
    finally { setSaving(false); }
  };

  return <Screen>
    <Header title="Finalização" subtitle="Revise o resumo e os dados de contato." />
    <SectionTitle title="Contato" />
    <Card>
      <Text style={fieldLabel}>Nome completo</Text>
      <TextInput value={name} onChangeText={setName} placeholder="Seu nome" style={inputStyle} />
      <Text style={fieldLabel}>E-mail</Text>
      <TextInput value={email} onChangeText={setEmail} placeholder="voce@email.com" keyboardType="email-address" autoCapitalize="none" style={inputStyle} />
    </Card>
    <SectionTitle title="Resumo" />
    <Card>
      {cart.map((item) => {
        const product = getProduct(item.productId);
        if (!product) return null;
        return <View key={item.productId} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}><Text style={{ flex: 1, color: colors.secondary, fontSize: 12 }}>{item.quantity} × {product.name}</Text><Text style={{ color: colors.text, fontWeight: '800', fontSize: 12 }}>{currency(product.price * item.quantity)}</Text></View>;
      })}
      <View style={{ height: 1, backgroundColor: colors.border }} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: colors.text, fontWeight: '900' }}>Subtotal</Text><Text style={{ color: colors.primaryDark, fontSize: 19, fontWeight: '900' }}>{currency(total)}</Text></View>
      <Text style={{ color: colors.muted, fontSize: 11 }}>Frete e disponibilidade não estão configurados nesta versão.</Text>
    </Card>
    <Card style={{ backgroundColor: '#FFF8E8', borderColor: '#F4E0B4' }}>
      <View style={{ flexDirection: 'row', gap: 9, alignItems: 'center' }}><Ionicons name="information-circle-outline" color={colors.warning} size={22} /><Text style={{ color: '#895B17', fontWeight: '900', flex: 1 }}>Pagamento desativado</Text></View>
      <Text style={{ color: '#916B31', fontSize: 12, lineHeight: 18 }}>Esta ação cria apenas um registro local do pedido para demonstração do fluxo. Não há cobrança, reserva de estoque, emissão de nota ou envio de produto.</Text>
    </Card>
    <Button title="Salvar pedido sem pagamento" icon="checkmark-circle-outline" onPress={() => void finalize()} loading={saving} disabled={cart.length === 0} />
  </Screen>;
}
const fieldLabel = { color: colors.secondary, fontSize: 12, fontWeight: '700' as const, marginBottom: 6 };
const inputStyle = { height: 47, borderRadius: 12, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 13, color: colors.text, marginBottom: 13 };
