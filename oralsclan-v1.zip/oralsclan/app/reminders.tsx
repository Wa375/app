import React, { useState } from 'react';
import { Alert, Switch, Text, TextInput, View } from 'react-native';
import { Button, Card, Header, Screen, SectionTitle } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { applyReminderSettings } from '@/services/notifications/reminders';
import { colors } from '@/theme/colors';

export default function RemindersScreen() {
  const { reminders, updateReminders } = useApp();
  const [morningEnabled, setMorningEnabled] = useState(reminders.morningEnabled);
  const [morningTime, setMorningTime] = useState(reminders.morningTime);
  const [eveningEnabled, setEveningEnabled] = useState(reminders.eveningEnabled);
  const [eveningTime, setEveningTime] = useState(reminders.eveningTime);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    const next = { morningEnabled, morningTime, eveningEnabled, eveningTime };
    for (const time of [morningTime, eveningTime]) {
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) { Alert.alert('Horário inválido', 'Use o formato HH:MM, por exemplo 07:30.'); return; }
    }
    setSaving(true);
    try {
      await applyReminderSettings(next);
      await updateReminders(next);
      Alert.alert('Lembretes atualizados', 'As notificações locais foram configuradas neste aparelho.');
    } catch (error) {
      Alert.alert('Não foi possível configurar', error instanceof Error ? error.message : 'Verifique as permissões do aparelho.');
    } finally { setSaving(false); }
  };

  return <Screen>
    <Header title="Lembretes" subtitle="Escolha horários para manter sua rotina em dia." />
    <SectionTitle title="Rotina da manhã" />
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><View style={{ flex: 1, gap: 3 }}><Text style={{ color: colors.text, fontWeight: '900' }}>Lembrete pela manhã</Text><Text style={{ color: colors.secondary, fontSize: 11 }}>Notificação diária</Text></View><Switch value={morningEnabled} onValueChange={setMorningEnabled} trackColor={{ false: '#DCE6ED', true: '#9BD6FA' }} thumbColor={morningEnabled ? colors.primary : '#FFFFFF'} /></View>
      <Text style={label}>Horário</Text>
      <TextInput value={morningTime} onChangeText={setMorningTime} keyboardType="numbers-and-punctuation" maxLength={5} placeholder="07:30" style={timeInput} />
    </Card>
    <SectionTitle title="Rotina da noite" />
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><View style={{ flex: 1, gap: 3 }}><Text style={{ color: colors.text, fontWeight: '900' }}>Lembrete à noite</Text><Text style={{ color: colors.secondary, fontSize: 11 }}>Notificação diária</Text></View><Switch value={eveningEnabled} onValueChange={setEveningEnabled} trackColor={{ false: '#DCE6ED', true: '#9BD6FA' }} thumbColor={eveningEnabled ? colors.primary : '#FFFFFF'} /></View>
      <Text style={label}>Horário</Text>
      <TextInput value={eveningTime} onChangeText={setEveningTime} keyboardType="numbers-and-punctuation" maxLength={5} placeholder="21:00" style={timeInput} />
    </Card>
    <Button title="Salvar lembretes" icon="notifications-outline" onPress={() => void save()} loading={saving} />
    <Card style={{ backgroundColor: colors.primarySoft, borderColor: '#D6EAF8' }}>
      <Text style={{ color: colors.primaryDark, fontWeight: '900' }}>Sobre as notificações</Text>
      <Text style={{ color: '#4C718B', fontSize: 12, lineHeight: 18 }}>Os lembretes são notificações locais programadas no aparelho. Eles não dependem de conexão com a escova ou com um servidor. A entrega pode depender das permissões e configurações de economia de bateria do sistema.</Text>
    </Card>
  </Screen>;
}
const label = { color: colors.secondary, fontSize: 12, fontWeight: '700' as const, marginTop: 10, marginBottom: 6 };
const timeInput = { backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 12, height: 46, paddingHorizontal: 13, color: colors.text, width: 110, fontWeight: '800' as const, fontSize: 16 };
